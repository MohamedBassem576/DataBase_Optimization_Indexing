--(Query 5)
select * from "Track" where "UnitPrice" != 0.99;

