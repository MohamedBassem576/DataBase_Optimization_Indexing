--(Query 13)
 select *
 from "Customer"
 where "Country" = 'Brazil';



