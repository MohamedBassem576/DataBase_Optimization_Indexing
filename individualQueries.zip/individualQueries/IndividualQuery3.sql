--(Query 3)
select p."Name" from "Playlist" p inner join "PlaylistTrack" pt on p."PlaylistId" = pt."PlaylistId" 
inner join "Track" t on t."TrackId" = pt."TrackId" where t."Composer" = 'AC/DC';

